// Student.h
#ifndef	STUDENT_H
#define STUDENT_H

#include <iostream>
#include "fixfld.h"
#include "length.h"
#include "delim.h"

using namespace std;

/*!
 * \brief Student Information.
 */
class Student 
{
  public:
  
	// fields
	char identifier [11]; /*!< Student identifier */
	char firstName [11]; /*!< Student first name */
	char lastName [16]; /*!< Student last name */
	char address [16]; /*!< Student address */
	char enrollmentDate [10]; /*!< Student enrollment date */
	int creditHoursCompleted; /*!< Student credit hours vompleted */
	
	/*!
    * \brief Default constructor.
    */
	Student();
	
	//operations
	/*!
    * \brief Gets the student identifier.
    * \return The student identifier.
    */
	const char* getIdentifier() const { return identifier; }
	
	/*!
    * \brief Getter methods of the student.
    * \return Info about the student.
    */
    const char* getFirstName() const { return firstName; }
    const char* getLastName() const { return lastName; }
    const char* getAddress() const { return address; }
    const char* getEnrollmentDate() const { return enrollmentDate; }
    int getCreditHoursCompleted() const { return creditHoursCompleted; }

	/*!
    * \brief Setter methods of the student.
    * \param item it is setting.
    */
    void setIdentifier(const char* id) { strcpy(identifier, id); }
    void setFirstName(const char* fName) { strcpy(firstName, fName); }
    void setLastName(const char* lName) { strcpy(lastName, lName); }
    void setAddress(const char* addr) { strcpy(address, addr); }
    void setEnrollmentDate(const char* date) { strcpy(enrollmentDate, date); }
    void setCreditHoursCompleted(int hours) { creditHoursCompleted = hours; }
	
	void incrementCreditHours(int hours) { creditHoursCompleted += hours; }
	
	/*!
    * \brief DelimFieldBuffer.
    * \param Buffer The DelimFieldBuffer to initialize.
    * \return 1 if successful, 0 otherwise.
    */
	static int InitBuffer (DelimFieldBuffer &);
	
	/*!
    * \brief LengthFieldBuffer.
    * \param Buffer The LengthFieldBuffer to initialize.
    * \return 1 if successful, 0 otherwise.
    */
	static int InitBuffer (LengthFieldBuffer &);
	
	/*!
    * \brief FixedFieldBuffer.
    * \param Buffer The FixedFieldBuffer to initialize.
    * \return 1 if successful, 0 otherwise.
    */
	static int InitBuffer (FixedFieldBuffer &);
	
	/*!
    * \brief Clears all data members of the Student object.
    */
	void Clear ();
	
	/*!
    * \brief Unpacks the Student object.
    * \param Buffer IOBuffer containing the packed Student object.
    * \return 1 if successful, 0 otherwise.
    */
	int Unpack (IOBuffer &);
	
	/*!
    * \brief Packs the Student object.
    * \param Buffer IOBuffer containing the packed Student object.
    * \return 1 if successful, 0 otherwise.
    */
	int Pack (IOBuffer &) const;
	
	/*!
	* \brief Prints the student information to the output stream.
	* \param stream Output stream to which the student information will be printed.
	* \param label.
	*/
	void Print (ostream &, char * label=0) const;
	
	 // Input and output operators
    friend std::istream& operator>>(std::istream& input, Student& student);
    friend std::ostream& operator<<(std::ostream& output, const Student& student);
};
#include "Student.cpp"
#endif
