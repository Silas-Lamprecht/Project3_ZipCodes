#include <fstream>
#include <iomanip>
#include "iobuffer.h"
#include "buffile.h"
#include "fixfld.h"
#include "length.h"
#include "Student.h" // Include the Student class header file

using namespace std;

// Declare instances of the Student class
Student JohnAmes;
Student AlanMason;
Student GARiccardi;
Student Padded;

/**
 * @brief Test the buffer with Student objects.
 * 
 * @tparam IOB Type of IOBuffer
 * @param Buff IOBuffer object
 * @param myfile Filename for storing buffer contents
 */
template <class IOB>
void testBuffer(IOB& Buff, char* myfile) {
    Student student;
    int result;
    int recaddr1, recaddr2, recaddr3, recaddr4;

    // Test writing
    BufferFile TestOut(Buff);
    result = TestOut.Create(myfile, ios::out);
    cout << "create file " << result << endl;
    if (!result) {
        cout << "Unable to create file " << myfile << endl;
        return;
    }
    JohnAmes.Pack(Buff);
    recaddr1 = TestOut.Write();
    cout << "write at " << recaddr1 << endl;
    AlanMason.Pack(Buff);
    recaddr2 = TestOut.Write();
    cout << "write at " << recaddr2 << endl;
    GARiccardi.Pack(Buff);
    recaddr3 = TestOut.Write();
    cout << "write at " << recaddr3 << endl;
    GARiccardi.Pack(Buff);
    recaddr4 = TestOut.Write();
    cout << "write at " << recaddr4 << endl;
    TestOut.Close();

    // test reading
    BufferFile TestIn(Buff);
    TestIn.Open(myfile, ios::in);
    TestIn.Read(recaddr3);
    student.Unpack(Buff);
    student.Print(cout);
    TestIn.Read(recaddr2);
    student.Unpack(Buff);
    student.Print(cout);
    TestIn.Read(recaddr1);
    student.Unpack(Buff);
    student.Print(cout);
    TestIn.Read(recaddr4);
    student.Unpack(Buff);
    student.Print(cout);
    result = TestIn.Read(recaddr4 * 2);
    if (result != -1)
        cout << "Read past end of file! Error." << endl;
    else
        cout << "Read past end of file failed! Correct." << endl;
}

/**
 * @brief Initialize Student objects.
 */
void InitStudent() {
    cout << "Initializing 3 Students" << endl;
    JohnAmes.setIdentifier("12345678");
    JohnAmes.setFirstName("John");
    JohnAmes.setLastName("Ames");
    JohnAmes.setAddress("123 Maple");
    JohnAmes.setEnrollmentDate("8/23/2022");
    JohnAmes.setCreditHoursCompleted(88);
    JohnAmes.Print(cout);
    AlanMason.setIdentifier("23456789");
    AlanMason.setFirstName("Alan");
    AlanMason.setLastName("Mason");
    AlanMason.setAddress("90 Eastgate");
    AlanMason.setEnrollmentDate("9/12/2021");
    AlanMason.setCreditHoursCompleted(75);
    AlanMason.Print(cout);
    GARiccardi.setIdentifier("34567890");
    GARiccardi.setFirstName("Gregory");
    GARiccardi.setLastName("Riccardi");
    GARiccardi.setAddress("2006 W Randolph");
    GARiccardi.setEnrollmentDate("10/5/2020");
    GARiccardi.setCreditHoursCompleted(100);
    GARiccardi.Print(cout);
}

/**
 * @brief Test the FixedFieldBuffer.
 */
void testFixedField ()
{
    cout << "Testing Fixed Field Buffer" << endl;
    FixedFieldBuffer Buff (6);
    Student::InitBuffer(Buff);
    char filename[] = "fixfile.dat";
    testBuffer(Buff, filename);
}

/**
 * @brief Test the LengthFieldBuffer.
 */
void testLength ()
{
    cout << "\nTesting LengthTextBuffer" << endl;
    LengthFieldBuffer Buff;
    Student::InitBuffer(Buff);
    char filename[] = "lenfile.dat";
    testBuffer(Buff, filename);
}

/**
 * @brief Test the DelimFieldBuffer.
 */
void testDelim ()
{
    cout << "\nTesting DelimTextBuffer" << endl;
    DelimFieldBuffer::SetDefaultDelim('|');
    DelimFieldBuffer Buff;
    Student::InitBuffer(Buff);
    char filename[] = "delfile.dat";
    testBuffer(Buff, filename);
}

/**
 * @brief Main function.
 */
int main(int argc, char** argv) {
    InitStudent();
    testFixedField();
    testLength();
    testDelim();
}