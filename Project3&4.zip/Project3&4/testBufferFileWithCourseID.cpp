#include <fstream>
#include <iomanip>
#include "iobuffer.h"
#include "buffile.h"
#include "fixfld.h"
#include "length.h"
#include "CourseRegisteration.h" // Include the CourseRegisteration class header file

using namespace std;

// Declare instances of the CourseRegisteration class
CourseRegisteration Math;
CourseRegisteration Reading;
CourseRegisteration CS;
CourseRegisteration Padded;

/**
 * @brief Test the buffer with CourseRegistration objects.
 * 
 * @tparam IOB Type of IOBuffer
 * @param Buff IOBuffer object
 * @param myfile Filename for storing buffer contents
 */
template <class IOB>
void testBuffer(IOB& Buff, char* myfile) {
    CourseRegisteration regis;
    int result;
    int recaddr1, recaddr2, recaddr3, recaddr4;

    // Test writing
    BufferFile TestOut(Buff);
    result = TestOut.Create(myfile, ios::out);
    cout << "create file " << result << endl;
    if (!result) {
        cout << "Unable to create file " << myfile << endl;
        return;
    }
    Math.Pack(Buff);
    recaddr1 = TestOut.Write();
    cout << "write at " << recaddr1 << endl;
    Reading.Pack(Buff);
    recaddr2 = TestOut.Write();
    cout << "write at " << recaddr2 << endl;
    CS.Pack(Buff);
    recaddr3 = TestOut.Write();
    cout << "write at " << recaddr3 << endl;
    CS.Pack(Buff);
    recaddr4 = TestOut.Write();
    cout << "write at " << recaddr4 << endl;
    TestOut.Close();

    // test reading
    BufferFile TestIn(Buff);
    TestIn.Open(myfile, ios::in);
    TestIn.Read(recaddr3);
    regis.Unpack(Buff);
    regis.Print(cout);
    TestIn.Read(recaddr2);
    regis.Unpack(Buff);
    regis.Print(cout);
    TestIn.Read(recaddr1);
    regis.Unpack(Buff);
    regis.Print(cout);
    TestIn.Read(recaddr4);
    regis.Unpack(Buff);
    regis.Print(cout);
    result = TestIn.Read(recaddr4 * 2);
    if (result != -1)
        cout << "Read past end of file! Error." << endl;
    else
        cout << "Read past end of file failed! Correct." << endl;
}

/**
 * @brief Initialize CourseRegistration objects.
 */
void InitCourse() {
    cout << "Initializing 3 Courses" << endl;
    Math.setCourseIdentifier("190527457");
    Math.setStudentIdentifier("dsg376e");
    Math.setCreditHours("5");
    Math.setCourseGrade("B-");
    Math.Print(cout);
    Reading.setCourseIdentifier("574385768");
    Reading.setStudentIdentifier("ad57ji9");
    Reading.setCreditHours("6");
    Reading.setCourseGrade("A+");
    Reading.Print(cout);
    CS.setCourseIdentifier("378595753");
    CS.setStudentIdentifier("de6t36g");
    CS.setCreditHours("4");
    CS.setCourseGrade("D");
    CS.Print(cout);
}

/**
 * @brief Test the FixedFieldBuffer.
 */
void testFixedField ()
{
    cout << "Testing Fixed Field Buffer" << endl;
    FixedFieldBuffer Buff (6);
    CourseRegisteration::InitBuffer(Buff);
    char filename[] = "fixfile.dat";
    testBuffer(Buff, filename);
}

/**
 * @brief Test the LengthFieldBuffer.
 */
void testLength ()
{
    cout << "\nTesting LengthTextBuffer" << endl;
    LengthFieldBuffer Buff;
    CourseRegisteration::InitBuffer(Buff);
    char filename[] = "lenfile.dat";
    testBuffer(Buff, filename);
}

/**
 * @brief Test the DelimFieldBuffer.
 */
void testDelim ()
{
    cout << "\nTesting DelimTextBuffer" << endl;
    DelimFieldBuffer::SetDefaultDelim('|');
    DelimFieldBuffer Buff;
    CourseRegisteration::InitBuffer(Buff);
    char filename[] = "delfile.dat";
    testBuffer(Buff, filename);
}

/**
 * @brief Main function.
 */
int main(int argc, char** argv) {
    InitCourse();
    testFixedField();
    testLength();
    testDelim();
}