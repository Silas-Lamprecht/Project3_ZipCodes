#include <iostream>
#include "Student.h"

int main() {
    // Create a Date object for the enrollment date
    Date enrollmentDate(1, 1, 2022);

    // Create a Student object
    Student student(12345, "John", "Doe", "123 Main St", enrollmentDate, 0);

    // Display student information
    std::cout << "Student Information:" << std::endl;
    std::cout << "ID: " << student.getIdentifier() << std::endl;
    std::cout << "First Name: " << student.getFirstName() << std::endl;
    std::cout << "Last Name: " << student.getLastName() << std::endl;
    std::cout << "Address: " << student.getAddress() << std::endl;
    std::cout << "Enrollment Date: " << student.getEnrollmentDate() << std::endl;
    std::cout << "Credit Hours Completed: " << student.getCreditHoursCompleted() << std::endl;

    // Increment credit hours and display updated information
    student.incrementCreditHours(3);
    std::cout << "After completing 3 credit hours:" << std::endl;
    std::cout << "Credit Hours Completed: " << student.getCreditHoursCompleted() << std::endl;

    return 0;
}