#include "Student.h"

/*!
 * \file Student.cpp
 * \brief Implementation file for the Student class
 */

/*!
 * \brief Default constructor for the Student class.
 * Initializes the Student object by calling the Clear() method.
 */
Student::Student() {
    Clear();
}

/*!
 * \brief Clears all fields of the Student object.
 */
void Student::Clear() {
    // Set each field to an empty string or 0
    identifier[0] = 0;
    firstName[0] = 0;
    lastName[0] = 0;
    address[0] = 0;
    enrollmentDate[0] = 0;
    creditHoursCompleted = 0;
}

/*!
 * \brief Packs the fields of the Student object into the provided buffer.
 * \param Buffer The IOBuffer to pack the fields into.
 * \return TRUE if packing succeeds, FALSE otherwise.
 */
int Student::Pack(IOBuffer& Buffer) const {
    int numBytes;
    Buffer.Clear();
    numBytes = Buffer.Pack(identifier);
    if (numBytes == -1) return FALSE;
    numBytes = Buffer.Pack(firstName);
    if (numBytes == -1) return FALSE;
    numBytes = Buffer.Pack(lastName);
    if (numBytes == -1) return FALSE;
    numBytes = Buffer.Pack(address);
    if (numBytes == -1) return FALSE;
    numBytes = Buffer.Pack(enrollmentDate);
    if (numBytes == -1) return FALSE;
    return TRUE;
}

/*!
 * \brief Unpacks the fields of the Student object from the provided buffer.
 * \param Buffer The IOBuffer to unpack the fields from.
 * \return TRUE if unpacking succeeds, FALSE otherwise.
 */
int Student::Unpack(IOBuffer& Buffer) {
    Clear();
    int numBytes;
    numBytes = Buffer.Unpack(identifier);
    if (numBytes == -1) return FALSE;
    identifier[numBytes] = 0;
    numBytes = Buffer.Unpack(firstName);
    if (numBytes == -1) return FALSE;
    firstName[numBytes] = 0;
    numBytes = Buffer.Unpack(lastName);
    if (numBytes == -1) return FALSE;
    lastName[numBytes] = 0;
    numBytes = Buffer.Unpack(address);
    if (numBytes == -1) return FALSE;
    address[numBytes] = 0;
    numBytes = Buffer.Unpack(enrollmentDate);
    if (numBytes == -1) return FALSE;
    enrollmentDate[numBytes] = 0;
    return TRUE;
}

/*!
 * \brief Initializes a FixedFieldBuffer to be used for packing Student objects.
 * \param Buffer The FixedFieldBuffer to initialize.
 * \return TRUE if initialization succeeds, FALSE otherwise.
 */
int Student::InitBuffer(FixedFieldBuffer& Buffer) {
    int result;
    result = Buffer.AddField(10);
    result = result && Buffer.AddField(10);
    result = result && Buffer.AddField(15);
    result = result && Buffer.AddField(15);
    result = result && Buffer.AddField(9);
    result = result && Buffer.AddField(2);
    return result;
}

/*!
 * \brief Initializes a DelimFieldBuffer to be used for packing Student objects.
 * \param Buffer The DelimFieldBuffer to initialize.
 * \return TRUE if initialization succeeds, FALSE otherwise.
 */
int Student::InitBuffer(DelimFieldBuffer& Buffer) {
    return TRUE;
}

/*!
 * \brief Initializes a LengthFieldBuffer to be used for packing Student objects.
 * \param Buffer The LengthFieldBuffer to initialize.
 * \return TRUE if initialization succeeds, FALSE otherwise.
 */
int Student::InitBuffer(LengthFieldBuffer& Buffer) {
    return TRUE;
}

/*!
 * \brief Prints the student information to the specified output stream.
 * \param stream The output stream to which the student information will be printed.
 * \param label Optional label to prepend to the output. Defaults to nullptr.
 */
void Student::Print(ostream& stream, char* label) const {
    if (label == 0) stream<< "Student:";
    else stream << label;
    stream << "\n\t Last Name '" << lastName << "'\n"
        << "\tFirst Name '" << firstName << "'\n"
        << "\t   Address '" << address << "'\n"
        << "\tEnrollment Date '" << enrollmentDate << "'\n"
        << "\tCredit Hours '" << creditHoursCompleted << "'\n";
}


std::istream& operator>>(std::istream& input, Student& student) {
    input >> student.identifier >> student.firstName >> student.lastName >> student.address >> student.enrollmentDate >> student.creditHoursCompleted;
    return input;
}

std::ostream& operator<<(std::ostream& output, const Student& student) {
    output << student.getIdentifier() << "\n"
           << student.getFirstName() << " " << student.getLastName() << "\n"
           << student.getAddress() << "\n"
           << student.getEnrollmentDate() << "\n"
           << student.getCreditHoursCompleted();

    return output;
}