#include <iostream>
#include <iomanip>
#include "Date.h"
#include "Student.h"
using namespace std;

Student::Student(int id = 0, const std::string& fName = "", const std::string& lName = "", const std::string& addr = "", const Date& date = Date(), int hours = 0) : identifier(id), firstName(fName), lastName(lName), address(addr), enrollmentDate(date), creditHoursCompleted(hours) {}

// Input operator implementation
std::istream& operator>>(std::istream& input, Student& student) {
    input>>student.identifier>>student.firstName>>student.lastName>>student.address>>student.enrollmentDate>>student.creditHoursCompleted;

    return input;
}

int Student::Pack (IOBuffer& Buffer) const
{// pack the fields into a FixedFieldBuffer, 
 // return TRUE if all succeed, FALSE o/w
	int numBytes;
	Buffer.Clear ();
	numBytes = Buffer . Pack (identifier);
	if (numBytes == -1) return FALSE;
	numBytes = Buffer . Pack (firstName);
	if (numBytes == -1) return FALSE;
	numBytes = Buffer . Pack (lastName);
	if (numBytes == -1) return FALSE;
	numBytes = Buffer . Pack (address);
	if (numBytes == -1) return FALSE;
	numBytes = Buffer . Pack (enrollmentDate);
	if (numBytes == -1) return FALSE;
	numBytes = Buffer . Pack (creditHoursCompleted);
	if (numBytes == -1) return FALSE;
	return TRUE;
}

int Student::Unpack(IOBuffer& buffer) {
    // Use buffer.ReadField methods to read each field from the buffer
    buffer.ReadField(identifier);
    buffer.ReadField(firstName);
    buffer.ReadField(lastName);
    buffer.ReadField(address);
    buffer.ReadField(enrollmentDate);
    buffer.ReadField(creditHoursCompleted);
    return 1; // Return 1 if successful, 0 otherwise
}

// Output operator implementation
std::ostream& operator<<(std::ostream& output, const Student& student) {
    output << student.getIdentifier() << "\n"
           << student.getFirstName() << " " << student.getLastName() << "\n"
           << student.getAddress() << "\n"
           << student.getEnrollmentDate() << "\n"
           << student.getCreditHoursCompleted();

    return output;
}