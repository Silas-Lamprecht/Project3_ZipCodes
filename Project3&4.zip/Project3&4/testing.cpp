#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
#include <string>
#include <map>

using namespace std;

struct Zipcode {
    string state;
    string zip;
    // Other fields...

    // Overload the < operator to allow sorting based on state IDs
    bool operator<(const Zipcode& other) const {
        return state < other.state;
    }
};

int main(){
    // Open the input CSV file
    ifstream inputFile("us_postal_codes.csv");
    if (!inputFile.is_open()) {
        cerr << "Error: Unable to open input file." << endl;
        return 1;
    }

    // Read data from the CSV file and store it in a vector
    vector<Zipcode> zipcodes;
    string line;
    while (getline(inputFile, line)) {
        stringstream ss(line);
        Zipcode zipcode;
        getline(ss, zipcode.state, ','); // Assuming state ID is the first column
        getline(ss, zipcode.zip, ',');
        // Parse other fields as needed...
        zipcodes.push_back(zipcode);
    }
    inputFile.close();

    // Sort the vector based on state IDs
    sort(zipcodes.begin(), zipcodes.end());

    // Open the output CSV file
    ofstream outputFile("output.csv");
    if (!outputFile.is_open()) {
        cerr << "Error: Unable to open output file." << endl;
        return 1;
    }

    // Write sorted data to the output CSV file
    for (const auto& zipcode : zipcodes) {
        outputFile << zipcode.state << "," << zipcode.zip << endl;
        // Write other fields as needed...
    }
    outputFile.close();

    cout << "Sorting and writing to output.csv completed successfully." << endl;

    return 0;
}