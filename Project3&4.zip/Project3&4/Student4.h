#include <iostream>
#include <string>
#include "Date.h"
#include "fixfld.h"
#include "length.h"
#include "delim.h"
#include "iobuffer.h"
#ifndef STUDENT_H
#define STUDENT_H

using namespace std;

class Student {
private:
    int identifier;
    std::string firstName;
    std::string lastName;
    std::string address;
    Date enrollmentDate;
    int creditHoursCompleted;

public:
    // Constructors
    Student(int id, const std::string& fName, const std::string& lName, const std::string& addr, const Date& date, int hours);

    // Methods to get/set data members
    int getIdentifier() const { return identifier; }
    std::string getFirstName() const { return firstName; }
    std::string getLastName() const { return lastName; }
    std::string getAddress() const { return address; }
    Date getEnrollmentDate() const { return enrollmentDate; }
    int getCreditHoursCompleted() const { return creditHoursCompleted; }

    void setIdentifier(int id) { identifier = id; }
    void setFirstName(const std::string& fName) { firstName = fName; }
    void setLastName(const std::string& lName) { lastName = lName; }
    void setAddress(const std::string& addr) { address = addr; }
    void setEnrollmentDate(const Date& date) { enrollmentDate = date; }
    void setCreditHoursCompleted(int hours) { creditHoursCompleted = hours; }

    // Method to increment the number of credit hours
    void incrementCreditHours(int hours) { creditHoursCompleted += hours; }
	
	int Unpack (IOBuffer&);
    int Pack (IOBuffer&) const;

    // Input and output operators
    friend std::istream& operator>>(std::istream& input, Student& student);
    friend std::ostream& operator<<(std::ostream& output, const Student& student);
};
#include "Student.cpp"
#endif